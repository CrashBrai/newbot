var config = {};

config.admins = [1358903791]//id админов бота

config.mongodb = 'mongodb://c33472_botdertevoooo_bot:PoKviPifmiqaw43@mongo1.c33472.h2,mongo2.c33472.h2,mongo3.c33472.h2/c33472_botdertevoooo_bot?replicaSet=MongoReplica'; // База бота MongoDB // Можно купить у @artemproger

config.qiwitoken = 'bd543861df124541e2457d2f97d6dcc7' ; // QIWI токен получить тут qiwi.com/api с 4 галочками

config.qiwinumber = 79875239243 // Номер киви без +

config.tokenbot = '1649086553:AAEVSRF6PqhEsgl46twgaC_uuUnD5kIaW4Y'

config.account = '1041123212'; // Номер payeer

config.apiPass = "" // Секретный ключ api payeer

config.apiId = 1239 // id api payeer

config.enabled = true

config.trees = [
	{
		id: 0,
		name: "Грушевое дерево",
		earn: 15,
		price: 10
	},
	{
		id: 1,
		name: "Лимонное дерево",
		earn: 35,
		price: 45
	},
	{
		id: 2,
		name: "Яблочное  дерево",
		earn: 70,
		price: 155
	},
	{
		id: 3,
		name: "Апельсиновое дерево",
		earn: 200,
		price: 265
	},
	{
		id: 4,
		name: "Банановое дерево",
		earn: 250,
		price: 460
	},
	{
		id: 5,
		name: "Сливовое дерево",
		earn: 400,
		price: 590
	},
	{
		id: 6,
		name: "Манговое дерево",
		earn: 900,
		price: 980
	},
	{
		id: 7,
		name: "Авокадное дерево",
		earn: 1000,
		price: 1500
	},
];  // цены,доходы и названия

config.startkeyboard = [
	["🌳 Деревья ", "🎁 Подарки", "⚡ Обменник"],
	["🖥 Личный кабинет", "👥 Партнёры"],
	["👑 Комната", "📚 О боте"]
];  // Клавиатура Start

config.referal = 0.1 // Цена за реферала

config.textstart = `
✌️ <b>Привет!</b>
📝 <b>Цель игры:</b>
├─Пополняем счет 🤘
├─Покупаем  деревья 🌳
├─Собираем энергию ⚡
├─Обмениваем доход 💵
└─Получаем деньги 💹

🏝 <b>Чат</b> 👉 @derevo4at
💳 <b>Выплаты</b> 👉 @derevotop
📢 <b>Новости</b> 👉 @derevonew` // Текст при нажатии /start

config.pers = 'Дерево '

config.perss = 'Деревьев '

config.persss = 'Деревьев '

config.minwithdraw = 5 // Минимальный вывод

config.maxwithdraw = 1.50 // В сколько раз можно окупится 

config.one = '🌳 Деревья'

config.one_one = '🛒 Магазин'

config.one_two = 'Мои деревья 🌳'

config.two = '🎁 Подарки'

config.two_one = '🎁 Подарок № 1'

config.three = '⚡ Обменник'

config.threetextone = 'В разделе ⚡ Обменник Вы сможете обменять <b>⚡ Энерию</b> на <b>₽ рубли</b>\n\n1000 ⚡ Энергии = 1 рубль\nМинимальная сумма обмена: 1000 Энергии'

config.threetexttwo = 'Энергия'

config.threetextthree = 'Плодов'

config.three_two = '🛍️ Продать ⚡'

config.four = '🖥 Личный кабинет'

config.four_one = '📥 Пополнить'

config.four_two = '📤 Вывести'

config.four_three = '♻️ Реинвест'

config.four_four = 'Мои деревья 🌳'

config.five = '👥 Партнёры'

config.bot = 'derevia_invest_bot' // Ссылка на бота без @

config.six = '👑 Комната'

config.six_one = '➕ Создать комнату'

config.six_two = '😎 ТОП Комнат'

config.six_three = '❗️ Статус битвы'

config.teplica_one = 'Комнате'

config.teplica_two = 'Комнатой'

config.teplica_three = 'Комната'

config.teplica_four = 'Комнаты'

config.teplica_five = 'Комнату'

config.teplica_six = 'Комнат'

config.admin = 'Artemka76' // Ссылка на админа без @
config.proger = 'PROGER_IT_RU'

config.chat = 'derevo4at' // Ссылка на Чат без @

config.deposit = 'derevotop' // Ссылка на канал с выплатами и пополнениями без @

config.novosti = 'derevonew' // Ссылка на канал с новостями без @

config.startbot = '5.01.2020' // Старт бота

config.limit = 15 // Лимит персонажей

config.ogorod = 'Энергия'

config.ogorode = 'Энергии'

config.prize = 'Грушевое дерево' // Подарок при подписки

config.prizecheck = 'romanovstavka'// Канал на который нужно подписатся чтоб получить подарок без

config.prizeid = 0 // id семена для подарка

module.exports = config;
